/// Simple 'Hello, world' program
/**
 * This program prints "Hello, world" to the LCD screen
 * @author Chad Nelson
 * @date 06/26/2012
 *
 * updated: phjones 9/3/2019
 * Description: Added timer_init call, and including Timer.h
 */

#include "Timer.h"
#include "lcd.h"


int main (void) {

    timer_init(); // Initialize Timer, needed before any LCD screen functions can be called
    // and enables time functions (e.g. timer_waitMillis)

    lcd_init();   // Initialize the LCD screen.  This also clears the screen.


    char text [] = "                    Microcontrollers are lots of fun!";
    char array [20];
    int index_begin = 0;
    int index_end = 19;
    int i = 0;


    while(1){
        for(i =0 ;i< 20; i++){
            array[i] = text[(i + index_begin) % strlen(text)];
        }
        lcd_printf(array);
        index_begin ++;
        index_end ++;
        timer_waitMillis(300);
    }


    /*char text [] = "Microcontrollers are lots of fun!";
	char array [20];
	int index_begin = 0;
	int index_end = 19;
	int i = 0;

	while(text[index_end]!= '\0'){
	    for(i =20 ;i< 20; i++){
	    array[i] = text[i + index_begin];
	}
	    lcd_printf(array);
	    index_begin ++;
	    index_end ++;
	    timer_waitMillis(300);
	}*/

    // Print "Hello, world" on the LCD
    //lcd_puts("Hello, world");
    //lcd_printf("Hello, world");

    // lcd_puts("Hello, world"); // Replace lcd_printf with lcd_puts
    // step through in debug mode and explain to TA how it works

    // NOTE: It is recommended that you use only lcd_init(), lcd_printf(), lcd_putc, and lcd_puts from lcd.h.
    // NOTE: For time functions, see Timer.h

    return 0;
}
