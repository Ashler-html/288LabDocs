///**
// * lab6_template.c
// *
// * Template file for CprE 288 Lab 6
// *
// * @author Diane Rover, 2/15/2020
// *
// */
//
//#include "Timer.h"
//#include "lcd.h"
//#include "cyBot_Scan.h"  // For scan sensors
//#include "uart.h"
//
//// Uncomment or add any include directives that are neede
//#include "open_interface.h"
//#include "movement.h"
//#include "button.h"
//
//
//#warning "Possible unimplemented functions"
//#define REPLACEME 0
//
//
//int main(void) {
//	timer_init(); // Must be called before lcd_init(), which uses timer functions
//	lcd_init();
//
//	uart_init();
//    cyBOT_init_Scan(0x7);
//
//	// YOUR CODE HERE
//
//	//for loop go over angles
////	{
////	   recieved_char =
//	   //if that is s stop
//	//otherwise scan
//////	}
//    oi_t *sensor_data = oi_alloc(); // do this only once at start of main()
//    oi_init(sensor_data);
//
//
//    char test = 0;
//    int angle = 0;
//    test = uart_receive_nonblocking();
//
//    uart_sendChar(test);
//    lcd_putc(test);
//
//    lcd_putc(test);
//    cyBOT_Scan_t scan_data;
//    if(test == 'f'){
//	while(angle < 180){
//	    lcd_putc('m');
//	    test = uart_receive_nonblocking();
//
//        cyBOT_Scan(angle, &scan_data);
//        lcd_printf("%.2lf\n%d", scan_data.sound_dist, scan_data.IR_raw_val);
//        if(test == 's'){
//            angle = 180;
//        }
//        angle++;
//	}
//	while(1)
//	{
//
//      // YOUR CODE HERE
//
//
//	}
//
//}
//}
