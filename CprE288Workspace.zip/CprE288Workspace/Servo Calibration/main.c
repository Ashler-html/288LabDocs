/// Simple 'Hello, world' program
/**
 * This program prints "Hello, world" to the LCD screen
 * @author Chad Nelson
 * @date 06/26/2012
 *
 * updated: phjones 9/3/2019
 * Description: Added timer_init call, and including Timer.h
 */

#include "Timer.h"
#include "lcd.h"
#include "open_interface.h"
#include "movement.h"
#include "cyBot_Scan.h"
#include "cyBot_uart.h"

typedef struct{
        float startAngle;
        float endAngle;
        float startDistance;
        float endDistance;
        float radWidth;
        float linWidth;
    } Objects;

void main() {
    lcd_init();
    timer_init();
  cyBOT_init_Scan(0x1);
  cyBOT_SERVO_cal();

  return 0;
}
// right: 274750 left: 1251250
