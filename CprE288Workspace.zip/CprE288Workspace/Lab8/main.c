/// Simple 'Hello, world' program
/**
 * This program prints "Hello, world" to the LCD screen
 * @author Chad Nelson
 * @date 06/26/2012
 *
 * updated: phjones 9/3/2019
 * Description: Added timer_init call, and including Timer.h
 */

#include "Timer.h"
#include "lcd.h"
#include "open_interface.h"
#include "movement.h"
#include "cyBot_Scan.h"
#include "cyBot_uart.h"
#include "uart-interrupt.h"
#include "adc.h"


void main(){
    timer_init();
    lcd_init();
    adc_init();
    uint16_t data;
    while(1){
        timer_waitMicros(200000);
        data = adc_read();
        lcd_printf("%d\n%lf", data, 4000000 * pow(data, -1.64));
    }
    oi_free(data);
}
