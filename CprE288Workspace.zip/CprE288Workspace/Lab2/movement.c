/*
 * movement.c
 *
 *  Created on: Feb 2, 2022
 *      Author: ltureaud
 */
#include "Timer.h"
#include "lcd.h"
#include "open_interface.h"
#include "movement.h"
void turn_right(oi_t *sensor, double degrees){
    double sum = 0;
    oi_setWheels(-300,300); //move forward at full speed
    while (sum < degrees) {
             oi_update(sensor);
             sum += (-1 * sensor -> angle);
             lcd_printf("%lf" ,sum);

    }

}
void turn_left(oi_t *sensor, double degrees){
    double sum = 0;
    oi_setWheels(300,-300); //move forward at full speed
    while (sum < degrees) {
             oi_update(sensor);
             sum += sensor -> angle;
             lcd_printf("%lf" ,sum);
    }

}
void move_forward(oi_t *sensor, double distance){
    double sum = 0; // distance member in oi_t struct is type double
    oi_setWheels(300,300); //move forward at full speed
    //oi_t *sensor_data = oi_alloc(); // do this only once at start of main()
    //oi_init(sensor_data);
        while (sum < distance) {

         oi_update(sensor);
         if(sensor->bumpLeft){
             move_backwards(sensor, 150);
             turn_right(sensor, 75);
             move_forward(sensor, 250);
             turn_left(sensor, 75);
             sum -= 150;
         } else if(sensor->bumpRight){
             move_backwards(sensor, 150);
             turn_left(sensor, 75);
             move_forward(sensor, 250);
             turn_right(sensor, 75);
             sum -= 150;
         }
         oi_setWheels(300,300); //move forward at full speed

         sum += sensor -> distance; // use -> notation since pointer
         lcd_printf("%lf" ,sum);
        }
}

        void move_backwards(oi_t *sensor, double distance){

            double sum = 0; // distance member in oi_t struct is type double
            oi_setWheels(-300,-300); //move forward at full speed
            while (sum < distance) {
                oi_update(sensor);
                sum += (-1 * sensor -> distance); // use -> notation since pointer
                lcd_printf("%lf" ,sum);
            }
        }
