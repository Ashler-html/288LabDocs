/*
 * movement.c
 *
 *  Created on: Feb 2, 2022
 *      Author: ltureaud
 */
#include "Timer.h"
#include "lcd.h"
#include "open_interface.h"
void turn_right(oi_t *sensor, double degrees){
    double sum = 0;
    oi_setWheels(-300,300); //move forward at full speed
    while (sum < degrees) {
             oi_update(sensor);
             sum += (-1 * sensor -> angle);


    }

}
void turn_left(oi_t *sensor, double degrees){
    double sum = 0;
    oi_setWheels(300,-300); //move forward at full speed
    while (sum < degrees) {
             oi_update(sensor);
             sum += sensor -> angle;

    }

}
void move_forward(oi_t *sensor, double distance){
    double sum = 0; // distance member in oi_t struct is type double
    oi_setWheels(300,300); //move forward at full speed
        while (sum < distance) {
         oi_update(sensor);
         sum += sensor -> distance; // use -> notation since pointer

        }
}

void move_backwards(oi_t *sensor, double distance){
    double sum = 0; // distance member in oi_t struct is type double
    oi_setWheels(-300,-300); //move forward at full speed
        while (sum < distance) {
         oi_update(sensor);
         sum += (-1 * sensor -> distance); // use -> notation since pointer
        }
}
