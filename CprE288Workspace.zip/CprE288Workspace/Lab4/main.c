/// Simple 'Hello, world' program
/**
 * This program prints "Hello, world" to the LCD screen
 * @author Chad Nelson
 * @date 06/26/2012
 *
 * updated: phjones 9/3/2019
 * Description: Added timer_init call, and including Timer.h
 */

#include "Timer.h"
#include "lcd.h"
#include "open_interface.h"
#include "movement.h"
#include "cyBot_Scan.h"
#include "cyBot_uart.h"
#include "button.h"

void main() {
    timer_init();
    lcd_init();
    button_init();
    cyBot_uart_init();
    while(1){
    switch(button_getButton()){
    case 0:
        lcd_printf("0");
        break;
    case 1:
        lcd_printf("1");
        cyBot_sendByte('a');
        break;
    case 2:
        lcd_printf("2");
        cyBot_sendByte('b');
        break;
    case 3:
        cyBot_sendByte('c');
        break;
    case 4:
        cyBot_sendByte('d');
        break;
    }
    }
}
