/*
 * servo.c
 *
 *  Created on: Apr 6, 2022
 *      Author: ltureaud
 */
#include "Timer.h"
#include "lcd.h"
void servo_init(void){
    SYSCTL_RCGCGPIO_R |= 0b00010;
    SYSCTL_RCGCTIMER_R |= 0b1000;

    //wait
    while ((SYSCTL_PRGPIO_R & 0x2) == 0) {};
    while ((SYSCTL_PRTIMER_R & 0x8) == 0) {};


    GPIO_PORTB_DIR_R &= ~0b100000;
    GPIO_PORTB_DEN_R |= 0b100000;
    GPIO_PORTB_AFSEL_R |= 0b100000; //changed
    GPIO_PORTB_PCTL_R |= 0x700000;
    TIMER1_CTL_R &= ~0b100000000;
    TIMER1_CFG_R |= 0x4;
    TIMER1_TBMR_R |= 0xA;
//    TIMER1_TBMR_R &= ~0x10;
//    TIMER1_CTL_R |= 0b110000000000;
    TIMER1_TBPR_R |= 0XFF; //wrong
    TIMER1_TBILR_R |= 0xFFFF; //wrong FORMULA
    TIMER1_TBMATCHR_R |= 0xFFFF;  //wrong
    TIMER1_TBPMR_R |= 0xFF;
    TIMER1_CTL_R |= 0x100;
//    TIMER1_IMR_R |= 0x400;
//    TIMER1_ICR_R |= 0x400;
//    TIMER1_CTL_R |= 0b100000000;
//    NVIC_EN1_R |= 0b10000;
//    NVIC_PRI9_R &= ~0x20;
//    NVIC_PRI9_R |= 0x20; //yeah IDK

}

void server_move(uint16_t degrees){

}
