/*
 * servo.h
 *
 *  Created on: Apr 6, 2022
 *      Author: ltureaud
 */

#ifndef SERVO_H_
#define SERVO_H_

void servo_init(void);

void server_move(uint16_t degrees);




#endif /* SERVO_H_ */
