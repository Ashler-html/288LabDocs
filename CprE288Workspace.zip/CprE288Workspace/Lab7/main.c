/// Simple 'Hello, world' program
/**
 * This program prints "Hello, world" to the LCD screen
 * @author Chad Nelson
 * @date 06/26/2012
 *
 * updated: phjones 9/3/2019
 * Description: Added timer_init call, and including Timer.h
 */

#include "Timer.h"
#include "lcd.h"
#include "open_interface.h"
#include "movement.h"
#include "cyBot_Scan.h"
#include "cyBot_uart.h"
#include "uart-interrupt.h"

typedef struct{
        float startAngle;
        float endAngle;
        float startDistance;
        float endDistance;
        float radWidth;
        float linWidth;
    } Objects;

void main() {
    lcd_init();
    timer_init();
    oi_t *sensor_data = oi_alloc(); // do this only once at start of main()
    oi_init(sensor_data); // do this only once at start of main()
    cyBot_uart_init();
    cyBOT_init_Scan(0x7);
    right_calibration_value = 274750;
    left_calibration_value = 1251250;
    int objNum = 0;
    Objects pipes[10];
    int j = 0;
    for(j = 0; j < 10; j++){
        pipes[j].radWidth = 100;
        pipes[j].startAngle = 0;
        pipes[j].endAngle = 0;
        pipes[j].startDistance = 0;
        pipes[j].endDistance = 0;
        pipes[j].radWidth = 0;
        pipes[j].linWidth = 0;

    }
    int objNum2 = 0;
        Objects pipes2[10];
        int k = 0;
        for(k = 0; k < 10; k++){
            pipes2[k].radWidth = 100;
            pipes2[k].startAngle = 0;
            pipes2[k].endAngle = 0;
            pipes2[k].startDistance = 0;
            pipes2[k].endDistance = 0;
            pipes2[k].radWidth = 0;
            pipes2[k].linWidth = 0;

        }
    cyBOT_Scan_t scan_data;
    cyBOT_Scan_t scan_data2;
    cyBOT_Scan(0, &scan_data);
   char test;
   int p = 0;

    while(1){
        test = cyBot_getByte();

        cyBot_sendByte(test);
        if(test == 'f'){

            int angle = 0;
            bool start = true;
            while(angle < 180){
                cyBOT_Scan(angle, &scan_data);
                lcd_printf("%.2lf\n%d", scan_data.sound_dist, scan_data.IR_raw_val);
                char str[] = "";
                sprintf(str, "%d\t%.2lf\t%d\r\n", angle, scan_data.sound_dist, scan_data.IR_raw_val);
                lcd_printf(str);
                uart_sendStr(str);
                angle += 1;

                if (scan_data.IR_raw_val > 1000){
                    if(start){
                        pipes[objNum].startAngle = angle;
                        pipes[objNum].startDistance = scan_data.sound_dist;
                        start = false;
                    }
                    pipes[objNum].endAngle = angle;
                    pipes[objNum].endDistance = scan_data.sound_dist;
                    pipes[objNum].radWidth = pipes[objNum].endAngle - pipes[objNum].startAngle;
                    pipes[objNum].linWidth = 2 *3.141 * pipes[objNum].startDistance * pipes[objNum].radWidth / 360;

                } if(scan_data.IR_raw_val < 1000 && start == false){
                    start = true;
                    objNum++;
                }

            }
            angle = 0;
            cyBOT_Scan(0, &scan_data);
            timer_waitMicros(1000);
                       start = true;
                       while(angle < 180){
                           cyBOT_Scan(angle, &scan_data2);
                           lcd_printf("%.2lf\n%d", scan_data2.sound_dist, scan_data2.IR_raw_val);
                           char str[] = "";
                           sprintf(str, "%d\t%.2lf\t%d\r\n", angle, scan_data2.sound_dist, scan_data2.IR_raw_val);
                           uart_sendStr(str);
                           angle += 1;

                           if (scan_data2.IR_raw_val > 1000){
                               if(start){
                                   pipes2[objNum2].startAngle = angle;
                                   pipes2[objNum2].startDistance = scan_data2.sound_dist;
                                   start = false;
                               }
                               pipes2[objNum2].endAngle = angle;
                               pipes2[objNum2].endDistance = scan_data2.sound_dist;
                               pipes2[objNum2].radWidth = pipes[objNum2].endAngle - pipes[objNum2].startAngle;
                               pipes2[objNum2].linWidth = 2 *3.141 * pipes[objNum2].startDistance * pipes[objNum2].radWidth / 360;
                               pipes2[objNum2].endAngle = pipes[objNum2].endAngle;

                           } if(scan_data2.IR_raw_val < 1000 && start == false){
                               start = true;
                               objNum2++;
                           }

                       }

}
        int j;
        for(j = 0; j < 10; j++){
            pipes[j].startDistance = pipes[j].startDistance + pipes2[j].startDistance / 2;
            pipes[j].endDistance = pipes[j].endDistance + pipes2[j].endDistance / 2;
            pipes[j].radWidth = pipes[j].radWidth + pipes2[j].radWidth / 2;
            pipes[j].linWidth = pipes[j].linWidth + pipes2[j].linWidth / 2;
        }
        int i;

        float degrees;
        float width = 100;
        degrees = pipes[0].startAngle;
        for(i = 0; i < 10; i++){
            if(pipes[i].radWidth < 5){
                pipes[i].radWidth = 200;
                pipes[i].linWidth = 1000;
            }

            if(pipes[i].linWidth < width){
                width = pipes[i].linWidth;
                degrees = (pipes[i].endAngle + pipes[i].startAngle) / 2;
                char str[] = "";
                sprintf(str, "%lf", pipes[i].linWidth);
                uart_sendStr(str);
            }
        }


        if(degrees > 90){
            turn_left(sensor_data, degrees-90);
            oi_setWheels(0,0);
        } else {
            turn_right(sensor_data, 90-degrees);
            oi_setWheels(0,0);
        }
       int bumped = move_forward(sensor_data, 200);
       if (bumped == 1){
           test = 'f';
       }
        oi_setWheels(0,0);
    }


    // Send a byte over the UART from CyBot and PuTTy (Buad Rate 115200, No Parity, No Flow Control)
//    //void cyBot_sendByte(char data);
//
//    // Cybot WAITs to recive a byte from PuTTy (Buad Rate 115200, No Parity, No Flow Control).
//    // In other words, this is a blocking fucntion.

   // oi_free(sensor_data);  // do this once at end of main()
}
