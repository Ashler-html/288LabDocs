/// Simple 'Hello, world' program
/**
 * This program prints "Hello, world" to the LCD screen
 * @author Chad Nelson
 * @date 06/26/2012
 *
 * updated: phjones 9/3/2019
 * Description: Added timer_init call, and including Timer.h
 */

#include "Timer.h"
#include "lcd.h"
#include "open_interface.h"
#include "movement.h"
#include "cyBot_Scan.h"
#include "cyBot_uart.h"

typedef struct{
    float startAngle;
    float endAngle;
    float startDistance;
    float endDistance;
    float radWidth;
    float linWidth;
} Objects;

void main() {
    lcd_init();
    timer_init();
    oi_t *sensor_data = oi_alloc(); // do this only once at start of main()
    oi_init(sensor_data); // do this only once at start of main()
    cyBot_uart_init();
    cyBOT_init_Scan(0x7);
    int objNum = 0;
    Objects pipes[100];
    int j = 0;
    for(j = 0; j < 10; j++){
        pipes[j].radWidth = 100;
    }
    cyBOT_Scan_t scan_data;
    char test;

    while(1){
        test = cyBot_getByte();

        cyBot_sendByte(test);
        if(test == 'f'){
            cyBot_Scan(0,&scan_data);
            int angle = 0;
            bool start = true;
            while(angle < 180){
                cyBOT_Scan(angle, &scan_data);
                lcd_printf("%.2lf\n%d", scan_data.sound_dist, scan_data.IR_raw_val);
                char str[] = "";
                sprintf(str, "%d\t%.2lf     %d\r\t\n", angle, scan_data.sound_dist, scan_data.IR_raw_val);
                cyBot_uart_sendStr(str);
                angle += 1;

                if (scan_data.IR_raw_val > 1000){
                    if(start){
                        pipes[objNum].startAngle = angle;
                        pipes[objNum].startDistance = scan_data.sound_dist;
                        start = false;
                    }
                    pipes[objNum].endAngle = angle;
                    pipes[objNum].endDistance = scan_data.sound_dist;
                    pipes[objNum].radWidth = pipes[objNum].endAngle - pipes[objNum].startAngle;
                    pipes[objNum].linWidth = tan(pipes[objNum].radWidth) * pipes[objNum].startDistance;
                    pipes[objNum].endAngle = pipes[objNum].endAngle;

                } if(scan_data.IR_raw_val < 1000 && start == false){
                    start = true;
                    objNum++;
                }

            }
        }
        int i;

        float degrees;
        float width = 100;
        degrees = pipes[0].startAngle;
        for(i = 0; i < 10; i++){

            if(pipes[i].radWidth < 3){
                pipes[i].radWidth = 100;
            }

            if(pipes[i].radWidth < width){
                width = pipes[i].radWidth;
                degrees = pipes[i].startAngle;
            }
        }
        if(degrees > 90){
            turn_left(sensor_data, degrees-90);
            oi_setWheels(0,0);
        } else {
            turn_right(sensor_data, 90-degrees);
            oi_setWheels(0,0);
        }
        move_forward(sensor_data, 200);
        oi_setWheels(0,0);
    }

    cyBot_uart_sendStr();

    // Send a byte over the UART from CyBot and PuTTy (Buad Rate 115200, No Parity, No Flow Control)
    //    //void cyBot_sendByte(char data);
    //
    //    // Cybot WAITs to recive a byte from PuTTy (Buad Rate 115200, No Parity, No Flow Control).
    //    // In other words, this is a blocking fucntion.

    // oi_free(sensor_data);  // do this once at end of main()
}
