/*
 * Movement.c
 *
 *  Created on: Feb 2, 2022
 *      Author: bmbates
 */

#include "open_interface.h"
#include "cyBot_uart.h"
#include "cyBot_Scan.h"


void move_to(int angleO[],float widthO[], oi_t* sensor, int distance[],int objects);
void Collision(oi_t *sensor);

void scan(int start, int end, oi_t *sensor){
    int angle; //current angle
    cyBOT_Scan_t getScan;
    int angleOut[30]; //Data going to  move to smallest
    float widthOut[30]; //Data going to move to smallest
    int distance[30];
    float p; //ping sensor data
    int IR; //IR sensor data
    cyBot_sendByte('\r');
    cyBot_sendByte('\n');
    char top[] = "Degrees PING Distance (cm) IR Value";
    //    Raw data vals top
    int printi;
    int i;
    for(printi = 0; printi < strlen(top);printi++){
        cyBot_sendByte(top[printi]);
    }
    char str[10];
    /**
     * Begin Actual Scan:
     * Store Max Distance. If greater than max, make new max. If distance found
     * less than 90% of max distance, new object has been found. Store start, end
     * angle and shortest distance of each object then display object and calculated
     * linear width in putty.
     */
    int objects = 1;

    bool at_obj = false;
    float min_dist; //At obj
    float max_dist;
    int start_a; //start deg of obj
    int end_a; //end deg of obj
    int mid_angle; //middle angle, to be printed to putty
    float lin_width;
    float max_p = 2000; //OBJECT SCAN DISTANCE
    float pees[50]; //store all ping dist for scan
    int angles[50]; //store all angle for scan
    int iraws[50]; //store all Raw IR Vals
    angle = start;
    i = 0; //reset index
    cyBOT_Scan(angle, &getScan);
    int iraw = getScan.IR_raw_val;
    for(angle = start; angle <= end; angle+=2){
        cyBOT_Scan(angle, &getScan);
        p = getScan.sound_dist;
        IR = getScan.IR_raw_val;
        pees[i] = p;
        angles[i] = angle;
        iraws[i] = IR;
        i++;
        // Display raw sensor data
        cyBot_sendByte('\r');
        cyBot_sendByte('\n');
        sprintf(str, "%d", angle);
        for(printi = 0; printi < strlen(str);printi++){
            cyBot_sendByte(str[printi]);
        }
        cyBot_sendByte('\t');
        sprintf(str, "%lf", p);
        for(printi = 0; printi < strlen(str);printi++){
            cyBot_sendByte(str[printi]);
        }cyBot_sendByte('\t');
        sprintf(str, "%d", IR);
        for(printi = 0; printi < strlen(str);printi++){
            cyBot_sendByte(str[printi]);
        }
        if(IR< iraw){ iraw=IR; }
    }


    /**
     * Scan through data to find objects using max p AKA max distance
     */
    int x;
    cyBot_sendByte('\r');
    cyBot_sendByte('\n');
    char pot[] = "Obj # Angle P Dist (cm) Lin Width (cm)";
    for(printi = 0; printi < strlen(pot);printi++){
        cyBot_sendByte(pot[printi]);
    }
    for(x = 0; x<i;x++){
        if(iraws[x]> 775){ //IS OBJECT
            if(at_obj){ //Look for closest distance and end of obj
                if(pees[x]< max_p*0.9){ //still an object
                    if(pees[x]>max_dist){ max_dist = pees[x];}
                    if(pees[x]<min_dist){
                        min_dist = pees[x];
                        mid_angle = angles[x];
                    }
                }
            }
            else{
                if(pees[x]< max_p*0.9){ //New Object Found
                    cyBot_sendByte('\r');
                    cyBot_sendByte('\n');
                    sprintf(str, "%d", objects);
                    for(printi = 0; printi < strlen(str);printi++){
                        cyBot_sendByte(str[printi]); //Print object Num to Putty
                    }
                    cyBot_sendByte('\t');
                    start_a = angles[x];
                    end_a = angles[x];
                    min_dist = pees[x];
                    max_dist = pees[x];
                    mid_angle = angles[x];
                    at_obj = true;
                    objects++;
                }
            }
        }
        else{ //NO longer an object
            if(at_obj){
                end_a = angles[x]-2;
                at_obj = false;
                sprintf(str, "%d", mid_angle);
                angleOut[objects-1] = mid_angle;
                for(printi = 0; printi < strlen(str);printi++){
                    cyBot_sendByte(str[printi]); //Print mid angle object in Putty
                }
                cyBot_sendByte('\t');
                sprintf(str, "%lf", min_dist);
                distance[objects-1] = min_dist;
                for(printi = 0; printi < strlen(str);printi++){
                    cyBot_sendByte(str[printi]); //Print dist to object in Putty
                }
                cyBot_sendByte('\t');
                lin_width = (end_a - start_a)/360.0 * 2.0 * 3.14 * max_dist;
                widthOut[objects-1] = lin_width;
                sprintf(str, "%lf", lin_width);
                for(printi = 0; printi < strlen(str);printi++){
                    cyBot_sendByte(str[printi]); //Print linear width to object in Putty
                }
                cyBot_sendByte('\t');
            }
        }
    }
    if(at_obj){ //End of scan, finalize object
        end_a = angles[x]-2;
        at_obj = false;
        sprintf(str, "%d", mid_angle);
        angleOut[objects-1] = mid_angle;
        for(printi = 0; printi < strlen(str);printi++){
            cyBot_sendByte(str[printi]); //Print mid angle object in Putty
        }
        cyBot_sendByte('\t');
        sprintf(str, "%lf", min_dist);
        distance[objects-1] = min_dist;
        for(printi = 0; printi < strlen(str);printi++){
            cyBot_sendByte(str[printi]); //Print dist to object in Putty
        }
        cyBot_sendByte('\t');
        lin_width = (end_a - start_a)/360.0 * 2.0 * 3.14 * max_dist;
        widthOut[objects-1] = lin_width;
        sprintf(str, "%lf", lin_width);
        for(printi = 0; printi < strlen(str);printi++){
            cyBot_sendByte(str[printi]); //Print linear width to object in Putty
        }
        cyBot_sendByte('\t');
    }
    move_to(angleOut, widthOut ,sensor, distance,objects);


}


double move_forward(oi_t *sensor_data, double distance_mm){
    double sum = 0; // distance member in oi_t struct is type double
      while (sum < distance_mm) {
       oi_setWheels(300,300); //move forward at full speed
       oi_update(sensor_data);
      // Collision(sensor_data);
       sum += sensor_data -> distance; // use -> notation since pointer
       lcd_printf("%lf" , sum);
      }
     oi_setWheels(0,0); //stop
     return sensor_data -> distance;
}
double move_back(oi_t *sensor_data, double distance_mm){
    double sum = 0; // distance member in oi_t struct is type double
      while (sum > -1 *distance_mm) {//?
       oi_setWheels(-500,-500); //move forward at full speed
       oi_update(sensor_data);
       sum += sensor_data -> distance; // use -> notation since pointer
       lcd_printf("%lf" , sum);
      }
     oi_setWheels(0,0); //stop
     return sensor_data -> distance;
}
void turn_right(oi_t *sensor,double degrees){
    double sum = 0; // distance member in oi_t struct is type double
     oi_setWheels(-100,100); //move forward at full speed
      while (sum > degrees * -0.9) {
       oi_update(sensor);
       sum += sensor -> angle; // use -> notation since pointer
       lcd_printf("%lf" , sum);
      }
     oi_setWheels(0,0); //stop
}
void turn_left(oi_t *sensor, double degrees){
    double sum = 0; // distance member in oi_t struct is type double
         oi_setWheels(100,-100); //move forward at full speed
          while (sum < degrees * 1.1) {
           oi_update(sensor);
           sum += sensor -> angle; // use -> notation since pointer
           lcd_printf("%lf" , sum);
          }
         oi_setWheels(0,0); //stop
}







int main(void){
      timer_init(); // Initialize Timer, needed before any LCD screen functions can be called
                    // and enables time functions (e.g. timer_waitMillis)
      lcd_init();
      oi_t *sensor_data = oi_alloc();
      oi_init(sensor_data);
      cyBot_uart_init();
      cyBOT_init_Scan(0b0111);
      while(1){
      char bite =   (char) cyBot_getByte();
      //cyBot_sendByte(bite);
      //lcd_printf("Got an %c", bite);

      if(bite == 'w'){
          move_forward(sensor_data, 100);

      }
      if(bite == 'a'){
          turn_left(sensor_data, 90);
      }
      if(bite == 'x'){
          move_back(sensor_data, 100);

      }
      if(bite == 'd'){
          turn_right(sensor_data, 90);
      }
      if(bite == 'm'){
          scan(40, 140,sensor_data);
      }
      if(bite == '.'){
          break;
      }
      }





      oi_free(sensor_data);
      return 0;
}

void Collision(oi_t *sensor){
    if(sensor->bumpLeft){
        move_back(sensor, 150);
        turn_right(sensor, 90);
        move_forward(sensor, 250);
        turn_left(sensor, 90);
    }
    else if(sensor->bumpRight){
        move_back(sensor, 150);
        turn_left(sensor, 90);
        move_forward(sensor, 250);
        turn_right(sensor, 90);
    }
}
void move_to(int angleO[],float widthO[], oi_t* sensor, int distance[],int objects){
    int i;
    int printi;
    float small = widthO[1];
    int index = 1;
    for(i = 2; i < objects; i+=1){ // going through ever other element of the array in order to determine smallest width.
        if(small > widthO[i]){
           small = widthO[i];
           index = i;
        }
    }
    double angel = (double) angleO[index]; //gotta pass them doubles
    char str[10];
    sprintf(str, "%lf", angel);
    for(printi = 0; printi < strlen(str);printi++){
        cyBot_sendByte(str[printi]); //Print mid angle object in Putty
    }
    cyBot_sendByte('\t');
    if(angel < 90){ //repeat for other angles > 90 and = 90;
        turn_right(sensor, 90-angel);
        move_forward(sensor,(distance[index] - 10) * 10);

    }
    else if(angel > 90){
        turn_left(sensor, angel-90);
        move_forward(sensor, (distance[index] - 10) * 10);
        char l[] = "Turning Left";
                    for(printi = 0; printi < strlen(l);printi++){
                        cyBot_sendByte(l[printi]);
                    }
    }
    else if(angel == 90){
        move_forward(sensor, (distance[index] - 10) * 10);
    }
    else{
        turn_right(sensor, 360);
        char oops[] = "Do a barrel roll";
            for(printi = 0; printi < strlen(oops);printi++){
                cyBot_sendByte(oops[printi]);
            }
    }
}

