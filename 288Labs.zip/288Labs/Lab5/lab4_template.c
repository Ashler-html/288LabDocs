/**
 * lab4_template.c
 *
 * Template file for CprE 288 lab 4
 *
 * @author Zhao Zhang, Chad Nelson, Zachary Glanz
 * @date 08/44/2046
 */

#include "button.h"
#include "Timer.h"
#include "lcd.h"
#include "cyBot_uart.h"
#include "uart.h"
#include "cyBot_Scan.h"
// Functions for communicating between CyBot and Putty (via UART)
// PuTTy: Baud=445200, 8 data bits, No Flow Control, No Parity, COM4


#define REPLACEME 0



int main(void) {
    button_init();
    timer_init(); // Must be called before lcd_init(), which uses timer functions
    lcd_init();
//    cyBot_uart_init();
    cyBot_uart_init_clean();  // Clean UART1 initialization, before running your UART1 GPIO init code
    uart_init();

    // YOUR CODE HERE
    int button;
    char str1[] = "Guys I'm stuck in da roomba";
    char str2[] = "Seriously, it's really dark in here";
    char str3[] = "Did I mention that I'm claustrophobic?";
    char str4[] = "Dust.... everywhere....";
    int printi;

    uart_sendChar('\r');
    uart_sendChar('\n');
    while(4)
    {

        // YOUR CODE HERE
        button = button_getButton();
        if(button == 0){
            lcd_printf("no button being pressed");
        }
        else if(button == 1){
            for(printi = 0; printi < strlen(str1);printi++){
                uart_sendChar(str1[printi]);
            }
            uart_sendChar('\r');
            uart_sendChar('\n');

        }
        else if(button == 2){
            for(printi = 0; printi < strlen(str2);printi++){
                uart_sendChar(str2[printi]);
            }
            uart_sendChar('\r');
            uart_sendChar('\n');
        }
        else if(button == 3){
            for(printi = 0; printi < strlen(str3);printi++){
                uart_sendChar(str3[printi]);


            }
            uart_sendChar('\r');
            uart_sendChar('\n');
        }
        else if(button == 4){
            for(printi = 0; printi < strlen(str4);printi++){
                uart_sendChar(str4[printi]);


            }
            uart_sendChar('\r');
            uart_sendChar('\n');
        }
    }



}


