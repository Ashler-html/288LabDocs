/**
 * lab5_template.c
 *
 * Template file for CprE 288 Lab 5
 *
 * @author Zhao Zhang, Chad Nelson, Zachary Glanz
 * @date 08/14/2016
 *
 * @author Phillip Jones, updated 6/4/2019
 * @author Diane Rover, updated 2/25/2021, 2/17/2022
 */

#include "button.h"
#include "timer.h"
#include "lcd.h"
#include "uart.h"
#include "string.h"
#include "stdio.h"

#include "cyBot_uart.h"  // Functions for communicating between CyBot and Putty (via UART1)
                         // PuTTy: Baud=115200, 8 data bits, No Flow Control, No Parity, COM1

#include "cyBot_Scan.h"  // Scan using CyBot servo and sensors


#define REPLACEME 0



int main(void) {
	button_init();
	timer_init(); // Must be called before lcd_init(), which uses timer functions
	lcd_init();
	char c[20];
	char str[10];
	int i = 0;
	int j = 0;
	for(i = 0; i < 20; i++){
	    c[i] = ' ';
	}

  // initialize the cyBot UART1 before trying to use it

	cyBot_uart_init_clean();  // Clean UART1 initialization, before running your UART1 GPIO init code
	uart_init();
	i=0;
	char urt;
	while(1){
	    urt = uart_receive();
	    if(urt == '\r'){
	        break;
	    }
	    else{

	        c[i] = urt;
	        i++;
	        if(i>=20){ break; }

	    }
	// YOUR CODE HERE

	}
	lcd_clear();
	    for(j = 0; j < 20;j++){
	        char x[1] = (char) c[j];
	        lcd_puts(x); //WORKS
	    }
	    //char y[] = (char) '\n';
//	    lcd_printf("\n"); //FROM HERE DOWN DOES NOT WORK
	    sprintf(str, "%d", i);
        lcd_puts(str);

//	    if(i == 20 || c[i] == '\n'){
//	    for(j = 0; j < 20;j++){
//	        lcd_printf("%c", c[i]);
//	    }
//	    lcd_printf("\n %d",i);
//	    i = 0;
//	    }


}
