/*
 * main.c
 *
 *  Created on: Apr 6, 2022
 *      Author: bmbates
 */
#include "servo.h"
#include "timer.h"

int main(void){
    timer_init(); // Must be called before lcd_init(), which uses timer functions
    servo_init();
    timer_waitMillis(400);
    servo_move(90);
    timer_waitMillis(400);
    servo_move(180);
    timer_waitMillis(400);
    servo_move(30);
    timer_waitMillis(400);
    servo_move(150);
    timer_waitMillis(400);
    servo_move(90);



    return 0;
}



