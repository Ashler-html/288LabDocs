/*
 * main.c
 *
 *  Created on: Mar 23, 2022
 *      Author: bmbates
 */
#include "adc.h"
#include "lcd.h"
#include "Timer.h"
#include "Movement.h"
#include "cyBot_uart.h"
#include "math.h"

/**CHECKPOINT:
putty interface still outputs P's, prolly something wrong w/ move forward because it outputs correct vals after program is closed

**/

int main(void){
    timer_init(); // Initialize Timer, needed before any LCD screen functions can be called
    lcd_init();   // Initialize the LCD screen.  This also clears the screen.
    adc_init();
    cyBot_uart_init();
    oi_t *sensor_data = oi_alloc();
    cyBOT_init_Scan(0b0111);
    cyBOT_Scan_t getScan;

    uart_interrupt_init();
    oi_init(sensor_data);
    right_calibration_value =  280000;
    left_calibration_value = 1261750;

    uint16_t data;
    int i;
//    for(i = 0; i < 10; i++){
//       data = adc_read();
//        lcd_printf("%d", data);
//        timer_waitMillis(3000);
//    }
    int cur;
    int est;
    int dist = 1000;
    char str[10];
    int printi;
    cyBOT_Scan(90, &getScan);
    while(1){
        cur = adc_read();
        //print cur
        cyBot_sendByte('\r');
        cyBot_sendByte('\n');
        est = (110841 * pow(cur,-1.156));
//        sprintf(str, "%d", cur);
//        for(printi = 0; printi < strlen(str);printi++){
//            cyBot_sendByte(str[printi]);
//        }
        sprintf(str, "%d", est);
        lcd_puts(str);
        lcd_putc(' ');
        lcd_putc(' ');
        lcd_putc(' ');
        sprintf(str, "%d", cur);
        lcd_puts(str);
        timer_waitMillis(300);
        lcd_clear();
    }

    for(i = 0; i<19; i++){
        move_forward(sensor_data,45);
        timer_waitMillis(500);
         cur = adc_read();
         //print cur and dist
         cyBot_sendByte('\r');
         cyBot_sendByte('\n');
         cur = (110841 * pow(cur,-1.156));
         sprintf(str, "%d", cur);
         for(printi = 0; printi < strlen(str);printi++){
             cyBot_sendByte(str[printi]);
         }
         cyBot_sendByte('\n');
         sprintf(str, "%d", dist);
         for(printi = 0; printi < strlen(str);printi++){
             cyBot_sendByte(str[printi]);
         }
         dist -= 50;
    }
    dist = 69.420;
    sprintf(str, "%d", dist);
    for(printi = 0; printi < strlen(str);printi++){
        cyBot_sendByte(str[printi]);
    }
    oi_free;



}

