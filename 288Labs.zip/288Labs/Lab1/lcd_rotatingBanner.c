/// Simple 'Hello, world' program
/**
 * This program prints "Hello, world" to the LCD screen
 * @author Chad Nelson
 * @date 06/26/2012
 *
 * updated: phjones 9/3/2019
 * Description: Added timer_init call, and including Timer.h
 */

#include "Timer.h"
#include "lcd.h"


int main (void) {
    timer_init(); // Initialize Timer, needed before any LCD screen functions can be called
                      // and enables time functions (e.g. timer_waitMillis)

    lcd_init();   // Initialize the LCD screen.  This also clears the screen.

    char c[] = "                    Microcontrollers are lots of fun!";
    lcd_init();
    signed int start = 1;
    int cur = start;
    int printed = 0;
    while(true){
        for(printed = 0; printed<20; printed++){
            char x[] = c[cur];
            lcd_puts(x);
            cur = (cur+1)%strlen(c);
        }
        timer_waitMillis(300);
        lcd_init();
        start = (start+1)%strlen(c);
        cur = start;
    }

    return 0;
}
