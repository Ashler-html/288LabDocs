/*
 * newMoves.h
 *
 *  Created on: Mar 23, 2022
 *      Author: bmbates
 */

#ifndef NEWMOVES_H_
#define NEWMOVES_H_

class newMoves
{
public:
    newMoves();
    virtual ~newMoves();
};

#endif /* NEWMOVES_H_ */
