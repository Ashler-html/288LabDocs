/*
 * lab7main.c
 *
 *  Created on: Mar 9, 2022
 *      Author: bmbates
 */

#include "open_interface.h"
#include "cyBot_uart.h"
#include "cyBot_Scan.h"
#include "uart-interrupt.h"
#include "Movement.h"
#include "adc.h"

extern volatile int command_flag;

extern volatile char command_byte;




int main(void){
    timer_init(); // Initialize Timer, needed before any LCD screen functions can be called
    // and enables time functions (e.g. timer_waitMillis)
    lcd_init();
    adc_init();
    uart_interrupt_init();
    oi_t *sensor_data = oi_alloc();
    oi_init(sensor_data);
    cyBOT_init_Scan(0b0111);

    //calibrate servos
    right_calibration_value =  280000;
    left_calibration_value = 1261750; //CyBot 6 REPLACE BEFORE USE

    //how to use addav addAv(double , &sum);
    //cyBOT_Scan_t getScan;
   // cyBOT_Scan(100, &getScan);
    Object objects[5];

    bool done = false;

    //turn_left(sensor_data, 90);

    while(1){

        if(command_byte == 'w'){
          //  oi_setWheels(300,300); //move forward at full speed
            move_forward(sensor_data, 100);

            done = true;
        }
        if(command_byte == 'a'){
            turn_left(sensor_data, 90);
            done = true;
        }
        if(command_byte == 'x'){
            move_back(sensor_data, 100);
            done = true;
        }
        if(command_byte == 'd'){
            turn_right(sensor_data, 90);
            done = true;
        }
        if(command_byte == 'm'){
            scan(0, 180,sensor_data, objects);
            done = true;
            //This scan should also move to smallest
        }
//        if(command_byte == '.'){
//            break;
//        }
        if(done){
            command_byte = ' ';
            done = false;
        }
    }





    oi_free(sensor_data);
    return 0;
}

