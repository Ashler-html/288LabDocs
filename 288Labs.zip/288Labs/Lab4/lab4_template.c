/**
 * lab4_template.c
 *
 * Template file for CprE 288 lab 4
 *
 * @author Zhao Zhang, Chad Nelson, Zachary Glanz
 * @date 08/44/2046
 */

#include "button.h"
#include "Timer.h"
#include "lcd.h"
#include "cyBot_uart.h"
#include "cyBot_Scan.h"// Functions for communicating between CyBot and Putty (via UART)
// PuTTy: Baud=445200, 8 data bits, No Flow Control, No Parity, COM4


#define REPLACEME 0



int main(void) {
    button_init();
    timer_init(); // Must be called before lcd_init(), which uses timer functions
    lcd_init();
    cyBot_uart_init();

    // YOUR CODE HERE
    int button;
    char str1[] = "Guys I'm stuck in da roomba";
    char str2[] = "Seriously, it's really dark in here";
    char str3[] = "Did I mention that I'm claustrophobic?";
    char str4[] = "Dust.... everywhere....";
    int printi;

    cyBot_sendByte('\r');
    cyBot_sendByte('\n');
    while(4)
    {

        // YOUR CODE HERE
        button = button_getButton();
        if(button == 0){
            lcd_printf("no button being pressed");
        }
        else if(button == 1){
            for(printi = 0; printi < strlen(str1);printi++){
                cyBot_sendByte(str1[printi]);
            }
            cyBot_sendByte('\r');
            cyBot_sendByte('\n');

        }
        else if(button == 2){
            for(printi = 0; printi < strlen(str2);printi++){
                cyBot_sendByte(str2[printi]);
            }
            cyBot_sendByte('\r');
            cyBot_sendByte('\n');
        }
        else if(button == 3){
            for(printi = 0; printi < strlen(str3);printi++){
                cyBot_sendByte(str3[printi]);


            }
            cyBot_sendByte('\r');
            cyBot_sendByte('\n');
        }
        else if(button == 4){
            for(printi = 0; printi < strlen(str4);printi++){
                cyBot_sendByte(str4[printi]);


            }
            cyBot_sendByte('\r');
            cyBot_sendByte('\n');
        }
    }



}


