/**
 * @file lab9_template.c
 * @author
 * Template file for CprE 288 Lab 9
 */

#include "Timer.h"
#include "lcd.h"
#include "ping_template.h"
#include "open_interface.h"
#include "cyBot_Scan.h"

// Uncomment or add any include directives that are needed

#define REPLACEME 0

int main(void) {
    timer_init(); // Must be called before lcd_init(), which uses timer functions
    lcd_init();
    ping_init();
    unsigned long out;
    oi_t *sensor_data = oi_alloc();
    cyBOT_init_Scan(0b0111);
    cyBOT_Scan_t getScan;
    cyBOT_Scan(90, &getScan);
    while(1)
    {
	    out = ping_getDistance();
	    if(out == (unsigned long) -69){
	        lcd_printf("didn't finish");
	    }
//        lcd_printf("%lu", out);
	    timer_waitMillis(100);


	}

}
