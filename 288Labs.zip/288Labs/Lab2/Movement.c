/*
 * Movement.c
 *
 *  Created on: Feb 2, 2022
 *      Author: bmbates
 */

#include "open_interface.h"


void Collision(oi_t *sensor);
double move_forward(oi_t *sensor_data, double distance_mm){
    double sum = 0; // distance member in oi_t struct is type double
      while (sum < distance_mm) {
       oi_setWheels(500,500); //move forward at full speed
       oi_update(sensor_data);
       Collision(sensor_data);
       sum += sensor_data -> distance; // use -> notation since pointer
       lcd_printf("%lf" , sum);
      }
     oi_setWheels(0,0); //stop
     return sensor_data -> distance;
}
double move_back(oi_t *sensor_data, double distance_mm){
    double sum = 0; // distance member in oi_t struct is type double
      while (sum > -1 *distance_mm) {//?
       oi_setWheels(-500,-500); //move forward at full speed
       oi_update(sensor_data);
       sum += sensor_data -> distance; // use -> notation since pointer
       lcd_printf("%lf" , sum);
      }
     oi_setWheels(0,0); //stop
     return sensor_data -> distance;
}
void turn_right(oi_t *sensor,double degrees){
    double sum = 0; // distance member in oi_t struct is type double
     oi_setWheels(-100,100); //move forward at full speed
      while (sum > degrees * -0.9) {
       oi_update(sensor);
       sum += sensor -> angle; // use -> notation since pointer
       lcd_printf("%lf" , sum);
      }
     oi_setWheels(0,0); //stop
}
void turn_left(oi_t *sensor, double degrees){
    double sum = 0; // distance member in oi_t struct is type double
         oi_setWheels(100,-100); //move forward at full speed
          while (sum < degrees) {
           oi_update(sensor);
           sum += sensor -> angle; // use -> notation since pointer
           lcd_printf("%lf" , sum);
          }
         oi_setWheels(0,0); //stop
}



int main(void){
     oi_t *sensor_data = oi_alloc();
      oi_init(sensor_data);
      timer_init(); // Initialize Timer, needed before any LCD screen functions can be called
                    // and enables time functions (e.g. timer_waitMillis)
      lcd_init();


      move_forward(sensor_data, 2000);





      /*
      turn_right(sensor_data, 90);
      move_forward(sensor_data, 500);
      turn_right(sensor_data, 90);
      move_forward(sensor_data, 500);
      turn_right(sensor_data, 90);
      move_forward(sensor_data, 500);
      turn_right(sensor_data, 90);
    */





      oi_free(sensor_data);
      return 0;
}

void Collision(oi_t *sensor){
    if(sensor->bumpLeft){
        move_back(sensor, 150);
        turn_right(sensor, 90);
        move_forward(sensor, 250);
        turn_left(sensor, 90);
    }
    else if(sensor->bumpRight){
        move_back(sensor, 150);
        turn_left(sensor, 90);
        move_forward(sensor, 250);
        turn_right(sensor, 90);
    }
}

