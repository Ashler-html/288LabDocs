/*
 * Movement.h
 *
 *  Created on: Feb 2, 2022
 *      Author: bmbates
 */

#ifndef MOVEMENT_H_
#define MOVEMENT_H_
#include "open_interface.h"

double move_foreward()


#endif /* MOVEMENT_H_ */
